package edu.lawrence.media.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.lawrence.media.entities.Profile;
import edu.lawrence.media.entities.User;

public interface ProfileRepository extends JpaRepository<Profile,Integer>{
	
	@Query("select p from Profile p where p.user.username = :username")
	Profile findByUsername(String username);
	
	List<Profile> findByUser(User u);
}

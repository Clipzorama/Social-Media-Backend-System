package edu.lawrence.media.interfaces;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.media.entities.Profile;
import edu.lawrence.media.interfaces.dtos.ProfileDTO;
import edu.lawrence.media.services.ProfileService;

@RestController
@RequestMapping("/profiles")
@CrossOrigin(origins = "*")
public class ProfileController {
	
	private ProfileService ps;
    
    public ProfileController(ProfileService ps) {
    	this.ps = ps;
    }
	
	@PostMapping("/{id}")
    public ResponseEntity<ProfileDTO> saveProfile(@PathVariable int id,@RequestBody ProfileDTO profile) {

    	int result = ps.save(id, profile);
    	
    	if (result==0)
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(profile);

    	profile.setProfileid(result);
    	return ResponseEntity.ok().body(profile);
    	
    }
    
	@GetMapping("/{username}")
    public ResponseEntity<ProfileDTO> getProfile(@PathVariable String username) {
        Profile result = ps.findProfileByUsername(username);
        if (result != null) {
            ProfileDTO response = new ProfileDTO(result);
            return ResponseEntity.ok().body(response);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
	
	@PostMapping("/archive/{profileid}/{userid}")
    public ResponseEntity<String> archive(@PathVariable int profileid, @PathVariable int userid) {
    	String result = ps.archive(profileid, userid);
    	return ResponseEntity.ok().body(result);
    }
	
	@PostMapping("/follow/{followerid}/{username}")
	public ResponseEntity<String> follow(@PathVariable int followerid, @PathVariable String username) {
		String result = ps.follow(followerid, username);
        if (result.contains("Follower not found")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Follower not found");
        } 
    	if (result.contains("Followee not found")) {
    		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Followee not found");
    	}
        return ResponseEntity.ok().body("Followed");
	}
	
	@PostMapping("/unfollow/{followerid}/{username}")
	public ResponseEntity<String> unfollow(@PathVariable int followerid, @PathVariable String username) {
		String result = ps.unfollow(followerid, username);
        if (result.contains("Follower not found")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Follower not found");
        } 
    	if (result.contains("Followee not found")) {
    		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Followee not found");
    	}
        return ResponseEntity.ok().body("Unfollowed");
	}
	
}

package edu.lawrence.media.interfaces;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.LikeDTO;
import edu.lawrence.media.services.LikeService;

@RestController
@RequestMapping("/likes")
@CrossOrigin(origins = "*")
public class LikeController {
	
	LikeService ls;
	
	public LikeController(LikeService ls) {
	    	this.ls = ls;
	}

	@PostMapping
	public ResponseEntity<LikeDTO> like(@RequestBody LikeDTO like) {
		String result = ls.save(like);
		if (result.contains("User not found"))
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(like);
		if (result.contains("Post not found"))
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(like);
		if (result.contains("Post already liked by user"))
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(like);
		if (result.contains("Post already disliked by user"))
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(like);
		return ResponseEntity.ok(like);
    }
	
	@GetMapping("/{postid}/quantityL")
	public ResponseEntity<Integer> quantityL(@PathVariable int postid) {
		int result = ls.getLikesByPostid(postid);
		return ResponseEntity.ok(result);
    }
	
	@GetMapping("/{postid}/quantityD")
	public ResponseEntity<Integer> quantityD(@PathVariable int postid) {
		int result = ls.getDislikesByPostid(postid);
		return ResponseEntity.ok(result);
    }
	
	@GetMapping("/{postid}/likes")
	public ResponseEntity<List<User>> likes(@PathVariable int postid) {
		List<User> result = ls.getUserLikes(postid);
		return ResponseEntity.ok(result);
    }
	
	@GetMapping("/{postid}/dislikes")
	public ResponseEntity<List<User>> dislikes(@PathVariable int postid) {
		List<User> result = ls.getUserDislikes(postid);
		return ResponseEntity.ok(result);
    }
	
}

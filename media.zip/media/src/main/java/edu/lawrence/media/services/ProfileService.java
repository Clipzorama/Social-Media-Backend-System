package edu.lawrence.media.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.media.entities.Profile;
import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.ProfileDTO;
import edu.lawrence.media.repositories.ProfileRepository;
import edu.lawrence.media.repositories.UserRepository;

@Service
public class ProfileService {
	
	@Autowired
	ProfileRepository pr;
	
	@Autowired
	UserRepository ur;
	
	public Profile findProfileByUsername(String username) {
        Optional<User> maybeUser = ur.findByUsername(username);
        if (maybeUser.isPresent()) {
            User user = maybeUser.get();
            Optional<Profile> maybeProfile = pr.findById(user.getUserid());
            if (maybeProfile.isPresent()) {
                Profile profile = maybeProfile.get();
                return profile;
            }
            return null;
        }
        return null;
	}

	
	public int save(int id, ProfileDTO profile) {
		
		Optional<User> maybeUser = ur.findById(id);
		if(!maybeUser.isPresent())
			return 0;
		
		User user = maybeUser.get();
		if(user.getProfile() != null)
			return 0;
		
		Profile newProfile = new Profile(profile);
		newProfile.setUser(user);
		pr.save(newProfile);
		return newProfile.getProfileid();
		
	}

	public String follow(int followerid, String followingName) {
		
		Optional<User> maybeFollower = ur.findByUserid(followerid);
		User follower;
		if (!maybeFollower.isPresent()) return "Follower not found";
        follower = maybeFollower.get();

		Optional<User> maybeFollowing = ur.findByUsername(followingName);
		User following;
		if (!maybeFollowing.isPresent()) return "Followee not found";
        following = maybeFollowing.get();
        
        if (following==follower) {
        	return "You can't follow yourself";
        }
		
        List<Profile> followerProfileList = pr.findByUser(follower);
        List<Profile> followingProfileList = pr.findByUser(following);
        
        Profile followerProfile = followerProfileList.get(0);
        Profile followingProfile = followingProfileList.get(0);
        
        followerProfile.followUser(following);
        followingProfile.followedByUser(follower);
        
		pr.save(followerProfile);
		pr.save(followingProfile);
		
		return "Followed";
		
	}

	public String unfollow(int followerid, String unfollowingName) {
		
		Optional<User> maybeFollower = ur.findByUserid(followerid);
		User follower;
		if (!maybeFollower.isPresent()) return "Follower not found";
        follower = maybeFollower.get();

		Optional<User> maybeFollowing = ur.findByUsername(unfollowingName);
		User following;
		if (!maybeFollowing.isPresent()) return "Followee not found";
        following = maybeFollowing.get();
		
        List<Profile> followerProfileList = pr.findByUser(follower);
        List<Profile> followingProfileList = pr.findByUser(following);
        
        if (following==follower) {
        	return "You can't follow yourself";
        }
        
        Profile followerProfile = followerProfileList.get(0);
        Profile followingProfile = followingProfileList.get(0);
        
        followerProfile.unfollowUser(following);
        followingProfile.unfollowedByUser(follower);
        
        pr.save(followerProfile);
		pr.save(followingProfile);
		
		return "Unfollowed";
	}
	
	public String archive(int profileid, int userid) {
		
		Optional<Profile> maybeProfile = pr.findById(profileid);
		
		if(!maybeProfile.isPresent())
			return "Comment not found";
		Profile profile = maybeProfile.get();
		
		if(profile.getUser().getUserid()!=userid)
			return "Invalid user";
		
		profile.setArchived(true);
		
		pr.save(profile);
		
		return "Archived";
		
	}
	
	
}

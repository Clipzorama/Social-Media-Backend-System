package edu.lawrence.media.entities;

import edu.lawrence.media.interfaces.dtos.PostDTO;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="posts")
public class Post {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int postid;
	@ManyToOne
	@JoinColumn(name="userid")
    private User user;
    private String text;
    private int likes;
    private int dislikes;
    private boolean archived;
    
    public Post() {}
    
    public Post(PostDTO core) {
    	text = core.getText().toString();
    	likes = core.getLikes();
    	dislikes = core.getDislikes();
    	archived = core.getArchived();
	}
    
    public int getPostid() {
		return postid;
	}
	public void setPostid(int postid) {
		this.postid = postid;
	}
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getText() {
		return text;
	}

	public void setFullname(String text) {
		this.text = text;
	}
	
	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}
	
	public int getDislikes() {
		return dislikes;
	}

	public void setDislikes(int dislikes) {
		this.dislikes = dislikes;
	}
	
	public boolean getArchived() {
		return archived;
	}
	
	public void setArchived(boolean archived) {
		this.archived = archived;
	}

}

package edu.lawrence.media.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.lawrence.media.entities.User;

public interface UserRepository extends JpaRepository<User,Integer>{
	
	@Query("select u from User u where u.username=:username")
	Optional<User> findByUsername(String username);

	@Query("select u from User u where u.userid=:userid")
	Optional<User> findByUserid(int userid);

	@Query("select u from User u where u.username=:username and u.password=:password")
	User findByUsernameAndPassword(String username, String password);
	
}

package edu.lawrence.media.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.media.entities.Comment;
import edu.lawrence.media.entities.Post;
import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.CommentDTO;
import edu.lawrence.media.repositories.CommentRepository;
import edu.lawrence.media.repositories.PostRepository;
import edu.lawrence.media.repositories.UserRepository;

@Service
public class CommentService {
	
	@Autowired
	CommentRepository cr;
	
	@Autowired
	UserRepository ur;
	
	@Autowired
	PostRepository pr;
	
	public String save(CommentDTO comment) {
		
		Optional<User> maybeUser = ur.findById(comment.getUser());
	    if(!maybeUser.isPresent())
	    	return "User not found";
	    User user = maybeUser.get();
	    
	    Optional<Post> maybePost = pr.findById(comment.getPost());
	    if(!maybePost.isPresent())
	    	return "Post not found";
	    Post post = maybePost.get();

		Comment newComment = new Comment(comment);
		newComment.setUser(user);
		newComment.setPost(post);
		cr.save(newComment);
		
		comment.setCommentid(newComment.getCommentid());
		return Integer.toString(newComment.getCommentid());
		
	}

	public List<CommentDTO> getCommentsByPostid(int postid) {
		
		List<Comment> commentList = cr.getCommentsByPostid(postid);

		List<CommentDTO> result = new ArrayList<CommentDTO>();
		
		for (int i=0; i<commentList.size(); i++) {
			CommentDTO newCommentDTO = new CommentDTO(commentList.get(i));
			result.add(newCommentDTO);
		}
		
		return result;
		
	}

	public String archive(int commentid, int userid) {
		
		Optional<Comment> maybeComment = cr.findById(commentid);
		
		if(!maybeComment.isPresent())
			return "Comment not found";
		Comment comment = maybeComment.get();
		
		if(comment.getUser().getUserid()!=userid)
			return "Invalid user";
		
		comment.setArchived(true);
		
		cr.save(comment);
		
		return "Archived";
		
	}

}

package edu.lawrence.media.interfaces.dtos;

import edu.lawrence.media.entities.Comment;

public class CommentDTO {
	private int commentid;
	private int post;
	private int user;
	private String content;
	private boolean archived;
	
	public CommentDTO() {}
	
	public CommentDTO(Comment core) {
		commentid = core.getCommentid();
    	user = core.getUser().getUserid();
    	post = core.getPost().getPostid();
    	content = core.getContent().toString();
    	archived = core.getArchived();
		
	}

	public int getCommentid() {
		return commentid;
	}

	public void setCommentid(int commentid) {
		this.commentid = commentid;
	}

	public int getPost() {
		return post;
	}

	public void setPost(int post) {
		this.post = post;
	}

	public int getUser() {
		return user;
	}

	public void setUser(int user) {
		this.user = user;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public boolean getArchived() {
		return archived;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}
	
	
}

package edu.lawrence.media.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import edu.lawrence.media.entities.Like;
import edu.lawrence.media.entities.User;

public interface LikeRepository extends JpaRepository<Like,Integer>{
	
	@Query("SELECT COUNT(l) FROM Like l WHERE l.post.postid = :postid AND l.liketype = true")
    int getLikesByPostid(@Param("postid") int postid);

    @Query("SELECT COUNT(l) FROM Like l WHERE l.post.postid = :postid AND l.liketype = false")
    int getDislikesByPostid(@Param("postid") int postid);

    @Query("SELECT l from Like l WHERE l.post.postid = :postid AND l.user.userid = :userid")
	Optional<Like> findByPostidAndUserid(int postid, int userid);

    @Query("SELECT l.user from Like l WHERE l.post.postid = :postid AND l.liketype = true")
	List<User> getLikeUsers(int postid);
    
    @Query("SELECT l.user from Like l WHERE l.post.postid = :postid AND l.liketype = false")
	List<User> getDislikeUsers(int postid);
	
}

package edu.lawrence.media.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.media.entities.Post;
import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.PostDTO;
import edu.lawrence.media.repositories.PostRepository;
import edu.lawrence.media.repositories.UserRepository;

@Service
public class PostService {

	@Autowired
	PostRepository pr;
	@Autowired
	UserRepository ur;
	
	public String save(PostDTO post) {
	    Optional<User> maybeUser = ur.findById(post.getUser());
	    if(!maybeUser.isPresent())
	    	return "User not found";
	    User user = maybeUser.get();
		Post newPost = new Post(post);
		newPost.setUser(user);
		pr.save(newPost);
		
		post.setPostid(newPost.getPostid());
		return Integer.toString(newPost.getPostid());
	}

	public PostDTO findByPostid(int postid) {
		
		Optional<Post> maybePost = pr.findById(postid);
		
		if(!maybePost.isPresent())
			return null;
		
		PostDTO post = new PostDTO(maybePost.get());
		return post;
		
	}

	public List<PostDTO> findByUser(User user) {
		
		List<Post> posts = pr.findByUser(user);
		
		if(posts.isEmpty())
			return null;
		
		List<PostDTO> postDTOs = new ArrayList<PostDTO>();
		
		for(int i = 0; i < posts.size(); i++) {
			PostDTO newPostDTO = new PostDTO(posts.get(i));
			postDTOs.add(newPostDTO);
		}
		
		return postDTOs;
		
	}

	public String archive(int postid, int userid) {
		
		Optional<Post> maybePost = pr.findById(postid);
		
		if(!maybePost.isPresent())
			return "Post not found";
		Post post = maybePost.get();
		
		if(post.getUser().getUserid()!=userid)
			return "Invalid user";
		
		post.setArchived(true);
		
		pr.save(post);
		
		return "Archived";
		
	}
	
}

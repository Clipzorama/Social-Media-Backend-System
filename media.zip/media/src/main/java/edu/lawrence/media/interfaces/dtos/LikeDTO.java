package edu.lawrence.media.interfaces.dtos;

import edu.lawrence.media.entities.Like;

public class LikeDTO {
	
	private int likeid;
	private int post;
    private int user;
    private boolean liketype;
    
    public LikeDTO() {}
    
    public LikeDTO(Like core) {
    	likeid = core.getLikeid();
    	post = core.getPost().getPostid();
    	user = core.getUser().getUserid();
    	liketype = core.getLiketype();
    }
    
    public int getLikeid() {
		return likeid;
	}
    
	public void setLikeid(int likeid) {
		this.likeid = likeid;
	}
   
    public int getPostid() {
		return post;
	}
    
	public void setPostid(int postid) {
		this.post = postid;
	}
	
	public int getUserid() {
		return user;
	}

	public void setUserid(int user) {
		this.user = user;
	}
    
    public boolean getLiketype() {
		return liketype;
	}
	
	public void setLiketype(boolean liketype) {
		this.liketype = liketype;
	}

}

package edu.lawrence.media.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import edu.lawrence.media.entities.Post;
import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.PostDTO;

public interface PostRepository extends JpaRepository<Post,Integer>{

	void save(PostDTO post);
	
	@Query("SELECT p FROM Post p WHERE p.user = :user")
	List<Post> findByUser(@Param("user") User user);

}

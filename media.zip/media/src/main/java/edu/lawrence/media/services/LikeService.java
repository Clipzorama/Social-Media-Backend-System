package edu.lawrence.media.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.media.entities.Like;
import edu.lawrence.media.entities.Post;
import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.LikeDTO;
import edu.lawrence.media.repositories.LikeRepository;
import edu.lawrence.media.repositories.PostRepository;
import edu.lawrence.media.repositories.UserRepository;

@Service
public class LikeService {
	
	@Autowired
	LikeRepository lr;
	
	@Autowired
	UserRepository ur;
	
	@Autowired
	PostRepository pr;

	public String save(LikeDTO like) {
		
		Optional<User> maybeUser = ur.findById(like.getUserid());
	    if(!maybeUser.isPresent())
	    	return "User not found";
	    User user = maybeUser.get();
	    
	    Optional<Post> maybePost = pr.findById(like.getPostid());
	    if(!maybePost.isPresent())
	    	return "Post not found";
	    Post post = maybePost.get();
	    
	    Optional<Like> maybeLike = lr.findByPostidAndUserid(like.getPostid(), like.getPostid());
	    if(maybeLike.isPresent()) {
	    	
	    	Like existingLike = maybeLike.get();
	    	if(existingLike.getLiketype()==like.getLiketype())
	    		return "Post already liked by user";

	    }
	    
	    if (like.getLiketype()) post.setLikes(post.getLikes()+1);
	    else post.setDislikes(post.getDislikes()+1);
	    
	    pr.save(post);

		Like newLike = new Like(like);
		newLike.setUser(user);
		newLike.setPost(post);
		lr.save(newLike);
		
		like.setLikeid(newLike.getLikeid());
		return Integer.toString(newLike.getLikeid());
		
	}

	public int getLikesByPostid(int postid) {
		
		int result = lr.getLikesByPostid(postid);
		return result;
		
	}

	public int getDislikesByPostid(int postid) {
		
		int result = lr.getDislikesByPostid(postid);
		return result;
		
	}

	public List<User> getUserLikes(int postid) {
		
		List<User> result = lr.getLikeUsers(postid);
		return result;
		
	}

	public List<User> getUserDislikes(int postid) {
		
		List<User> result = lr.getDislikeUsers(postid);
		return result;
		
	}
	
}

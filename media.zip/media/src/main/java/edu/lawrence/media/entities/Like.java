package edu.lawrence.media.entities;

import edu.lawrence.media.interfaces.dtos.LikeDTO;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

// ensures that the combination of postid and userid is unique, meaning a user can only like a particular post once
@Entity
@Table(name = "likes", uniqueConstraints = {
	    @UniqueConstraint(columnNames = {"postid", "userid"})
	})
public class Like {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int likeid;
	@ManyToOne
	@JoinColumn(name="postid")
	private Post post;
	@ManyToOne
	@JoinColumn(name="userid")
    private User user;
	private boolean liketype; // true --> like , false --> dislike 
	
	public Like() {}
    
    public Like(LikeDTO core) {
    	liketype = core.getLiketype();
	}
    
    public int getLikeid() {
		return likeid;
	}
	public void setLikeid(int likeid) {
		this.likeid = likeid;
	}
	
	public Post getPost() {
		return post;
	}
	
	public void setPost(Post post) {
		this.post = post;
	}
	
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public boolean getLiketype() {
		return liketype;
	}
	
	public void setLiketype(boolean liketype) {
		this.liketype = liketype;
	}

}

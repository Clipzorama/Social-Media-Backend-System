package edu.lawrence.media.interfaces;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.media.interfaces.dtos.CommentDTO;
import edu.lawrence.media.services.CommentService;
import edu.lawrence.media.services.UserService;

@RestController
@RequestMapping("/comments")
@CrossOrigin(origins = "*")
public class CommentController {
	
	CommentService cs;
	UserService us;
	
	public CommentController(CommentService cs, UserService us) {
	    	this.cs = cs;
	    	this.us = us;
	}
	
	@PostMapping
	public ResponseEntity<CommentDTO> save(@RequestBody CommentDTO comment) {
		String result = cs.save(comment);
		if (result.contains("User not found"))
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(comment);
		if (result.contains("Post not found"))
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(comment);
		return ResponseEntity.ok(comment);
    }
	
	@GetMapping("/{postid}")
	public ResponseEntity<List<CommentDTO>> findByPostid(@PathVariable int postid) {
		List<CommentDTO> result = cs.getCommentsByPostid(postid);
		if (result.isEmpty())
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(result);
		return ResponseEntity.ok(result);
    }
	
	@PostMapping("/archive/{commentid}/{userid}")
    public ResponseEntity<String> archive(@PathVariable int commentid, @PathVariable int userid) {
    	String result = cs.archive(commentid, userid);
		if (result.contains("Archived"))
				return ResponseEntity.ok().body(result);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
    }

}

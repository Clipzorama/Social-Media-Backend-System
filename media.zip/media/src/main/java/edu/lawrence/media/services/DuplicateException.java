package edu.lawrence.media.services;

@SuppressWarnings("serial")
public class DuplicateException extends Exception {
	public DuplicateException() {
		super("Attempt to insert duplicate element.");
	}
}

package edu.lawrence.media.interfaces.dtos;

import java.util.Set;

import edu.lawrence.media.entities.Profile;

public class ProfileDTO {
	
	private int profileid;
	private int userid;
	private String fullname;
	private int age;
	private String gender;
	private String bio;
	private Set<String> followingids;
    private Set<String> followerids;
    private boolean archived;
    
	
	public ProfileDTO() {}

	public ProfileDTO(Profile core) {
		userid = core.getUser().getUserid();
		fullname = core.getFullname();
		age = core.getAge();
		gender = core.getGender();
		bio = core.getBio();
		archived = core.getArchived();
	}

	public int getProfileid() {
		return profileid;
	}

	public void setProfileid(int profileid) {
		this.profileid = profileid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

    public Set<String> getFollowingids() {
		return followingids;
	}

	public void setFollowingids(Set<String> followingids) {
		this.followingids = followingids;
	}

	public Set<String> getFollowerids() {
		return followerids;
	}

	public void setFollowerids(Set<String> followerids) {
		this.followerids = followerids;
	}

	public boolean getArchived() {
		return archived;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}
	
	
	
}

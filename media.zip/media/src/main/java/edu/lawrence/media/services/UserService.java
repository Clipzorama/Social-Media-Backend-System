package edu.lawrence.media.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.media.entities.Profile;
import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.ProfileDTO;
import edu.lawrence.media.interfaces.dtos.UserDTO;
import edu.lawrence.media.repositories.ProfileRepository;
import edu.lawrence.media.repositories.UserRepository;


@Service
public class UserService {

	@Autowired
	PasswordService passwordService;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ProfileRepository profileRepository;
	
	public int save(UserDTO user) {
		
	    Optional<User> existing = userRepository.findByUsername(user.getUsername());
	    if (!existing.isEmpty()) {
	        return 0;
	    }
	    
		User newUser = new User();
		newUser.setUsername(user.getUsername());
		String hash = passwordService.hashPassword(user.getPassword());
	    newUser.setPassword(hash);
	    userRepository.save(newUser);
	    
		return newUser.getUserid();
	}
	
	public User findByUsernameAndPassword(String username,String password) {
		
		Optional<User> existing = userRepository.findByUsername(username);
		if(existing.isEmpty())
			return null;
		User u = existing.get();
		if(passwordService.verifyHash(password, u.getPassword())) {
        	u.setPassword("Undisclosed");
        } else {
        	u = null;
        }
        return u;	
	}
	
	public User findByUserid(int userid) {
        return userRepository.findById(userid)
            .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + userid));
    }
	
	public String saveProfile(int userid,ProfileDTO profile) {
		Optional<User> maybeUser = userRepository.findById(userid);
		if(!maybeUser.isPresent())
			return "Bad Id";
		
		User user = maybeUser.get();
		if(user.getProfile() != null)
			return "Duplicate";
		
		Profile newProfile = new Profile(profile);
		newProfile.setUser(user);
		profileRepository.save(newProfile);
		
		return "Created";
	}

	public User findByUsername(String username) {
		Optional<User> maybeUser = userRepository.findByUsername(username);
        if (maybeUser.isPresent()) {
            User user = maybeUser.get();
                return user;
            }
            return null;
	}
	
}
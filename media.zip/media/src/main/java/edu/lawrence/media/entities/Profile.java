package edu.lawrence.media.entities;


import java.util.Set;

import edu.lawrence.media.interfaces.dtos.ProfileDTO;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="profiles")
public class Profile {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int profileid;
	@OneToOne
	@JoinColumn(name="user")
	private User user;
	private String fullname;
	private int age;
	private String gender;
	private String bio;
	
    @ManyToMany
    private Set<User> followers;
    
    @ManyToMany
    private Set<User> following;
    
    private boolean archived;
	
	public Profile() {}

	public Profile(ProfileDTO core) {
		fullname = core.getFullname();
		age = core.getAge();
		gender = core.getGender();
		bio = core.getBio();
		archived = core.getArchived();
	}
	

	public int getProfileid() {
		return profileid;
	}

	public void setProfileid(int profileid) {
		this.profileid = profileid;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}
	
	public void followUser(User u) {
		this.following.add(u);
	}
	
	public void followedByUser(User u) {
		this.followers.add(u);
	}

	public void unfollowUser(User u) {
		this.following.remove(u);
	}
	
	public void unfollowedByUser(User u) {
		this.followers.remove(u);
	}

	public boolean getArchived() {
		return archived;
	}

	public void setArchived(boolean archived) {
		this.archived = archived;
	}
	
}

package edu.lawrence.media.interfaces;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.PostDTO;
import edu.lawrence.media.services.PostService;
import edu.lawrence.media.services.UserService;

@RestController
@RequestMapping("/posts")
@CrossOrigin(origins = "*")
public class PostController {

	private PostService ps;
	private UserService us;
    
    public PostController(PostService ps, UserService us) {
    	this.ps = ps;
    	this.us = us;
    }
	
	@PostMapping
    public ResponseEntity<PostDTO> savePost(@RequestBody PostDTO post) {
    	String result = ps.save(post);
    	if (result.contains("User not found"))
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(post);
    	return ResponseEntity.ok().body(post);
    }
    
	@GetMapping("/post/{postid}")
    public ResponseEntity<PostDTO> findByPostid(@PathVariable int postid) {
    	PostDTO result = ps.findByPostid(postid);
    	if (result == null) {
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
    	}
    	return ResponseEntity.ok().body(result);
    }
	
	@GetMapping("/user/{username}")
    public ResponseEntity<List<PostDTO>> findByUsername(@PathVariable String username) {
		
		List<PostDTO> result = new ArrayList<>();
		
		User user = us.findByUsername(username);
		
    	if (user == null) {
    		return ((BodyBuilder) ResponseEntity.noContent()).body(result);
    	}
    	
    	result = ps.findByUser(user);
    	
    	return ResponseEntity.ok().body(result);
    }
	
	@PostMapping("/archive/{postid}/{userid}")
    public ResponseEntity<String> archive(@PathVariable int postid, @PathVariable int userid) {
    	String result = ps.archive(postid, userid);
    	
		if (result.contains("Archived"))
				return ResponseEntity.ok().body(result);
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
    }
    
}

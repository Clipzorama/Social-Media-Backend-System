package edu.lawrence.media.interfaces;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.media.entities.User;
import edu.lawrence.media.interfaces.dtos.UserDTO;
import edu.lawrence.media.services.UserService;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*")
public class UserController {
	
	private UserService us;
    
    public UserController(UserService us) {
        this.us = us;
    }
    
    @PostMapping
    public ResponseEntity<String> save(@RequestBody UserDTO user) {
    	
        if (user.getUsername().isBlank() || user.getPassword().isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Empty user name or password");
        }
        
        int key;

    	key = us.save(user);
    	
    	if (key==0)
    		return ResponseEntity.status(HttpStatus.CONFLICT).body("User exists");
        
        return ResponseEntity.status(HttpStatus.CREATED).body(Integer.toString(key));
        
    }
    
    @PostMapping("/login")
    public ResponseEntity<String> checkLogin(@RequestBody UserDTO user) {
        User result = us.findByUsernameAndPassword(user.getUsername(), user.getPassword());
        if (result == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid user name or password");
        }
        return ResponseEntity.ok().body(Integer.toString(result.getUserid()));
    }
    
}